#ifndef _RDR_H_
#define _RDR_H_

char *createNewFile_RDR(char *);

void printAll_RDR(char *);

void printViaField_RDR(char *, int, char *);

void printViaPosition_RDR(char *, int);

void printViaPosField_RDR(char *, int, int);

#endif