#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <rff.h>
#include <rsi.h>
#include <rdr.h>
#include <filestrings.h>

//Function to read file from user
char *new_file(){
        char *name;
        printf("==============================\nGOVERNAMENTAL DOMAIN DATAS\n==============================\n");
        printf("Type the name of the file:\n>>>");
        name = readString();
        system("clear");
        return name;
}

//Function to select the way to work with records
int record_type(){
        int option;
        printf("Select the type of file organization.\n");
        printf("================ORGANIZATIONS================\n");
        printf("[1] -> Records with variable sizes and indicators.\n");
        printf("[2] -> Records with variable sizes and field delimiters.\n");
        printf("[3] -> Records with variable sizes and fixed number in field.\n>>>");
        scanf("%d%*c", &option);
        system("clear");
        return option;

}
//Function to display the menu for the user to select the task to perform
int menu(){
        int option;
        printf("Select the operation to perform.\n");
        printf("================OPERATIONS================\n");
        printf("[1] -> Display data from file.\n");
        printf("[2] -> Display data by criteria (ex:Domain).\n");
        printf("[3] -> Display data from specific record.\n");
        printf("[4] -> Display data from specific record and specific field.\n");
        printf("[5] -> Exit.\n>>>");
        scanf("%d%*c",&option);
        system("clear");
        return option;
}
//Function to display the diferents field that exist for the case 2 and 4 of the menu
int fields(){
        int field;
        printf("Select the wanted field.\n");
        printf("================FIELDS================\n");
        printf("[1] -> Domain.\n");
        printf("[2] -> Document.\n");
        printf("[3] -> Name.\n");
        printf("[4] -> State.\n");
        printf("[5] -> City.\n");
        printf("[6] -> Date of record.\n");
        printf("[7] -> Date of Update.\n");
        printf("[8] -> Ticket.\n>>>");
        scanf("%d%*c",&field );
        system("clear");
        return field;
}


int main (int argc,char *argv[]){
        char *file_name, *output_file;
        char * key;
        bool stop = false; //Stop program
        int menu_op, position, field, regType;

        //Read the name of file
        file_name = new_file();
        //Display menu opcion
        regType = record_type();

        //Switch to select between RSI,RDR,RFF
        switch (regType) {

        case 1: // RSI
                //Create output file
                output_file = createNewFile_RSI(file_name);
                
                while(!stop){
                        //Display menu
                        menu_op = menu();
                        switch (menu_op) {
                        case 1: // Show data from file
                                printAll_RSI(output_file);
                                break;
                        case 2:// Search by given value
                                field = fields();//Select field to search by
                                printf("Type the what to search in the file.\n>>>" );
                                key = readString();
                                printViaField_RSI(output_file,field,key);
                                break;
                        case 3: // Show data from a record
                                printf("Type the record number.\n>>>");
                                scanf("%d%*c",&position);
                                printViaPosition_RSI(output_file,position);
                                break;
                        case 4: // Show data frome a given record and field
                                printf("Type the record number.\n>>>");
                                scanf("%d%*c", &position);
                                field = fields(); //Select field to search by
                                printViaPosField_RSI(output_file,position,field);
                                break;
                        case 5:// Exit program
                                stop = true; //Stop while and exit
                                break;
                        default:
                                printf("Option was not selected.\n");
                                break;
                        }
                        
                }        
        case 2: //RDR
                output_file = createNewFile_RDR(file_name);
                menu_op = menu();
                switch (menu_op) {
                case 1: // Show data from file
                        printAll_RDR(output_file);
                        break;
                case 2:// Search by given value
                        field = fields(); //Select field to search by
                        printf("Type the what to search.\n>>>" );
                        key = readString();
                        printViaField_RDR(output_file,field,key);
                        break;
                case 3: // Show data from a record
                        printf("Type the record number.\n>>>");
                        scanf("%d%*c",&position);
                        printViaPosition_RDR(output_file,position);
                        break;
                case 4: // Show data frome a given record and field
                        printf("Type the record number.\n>>>");
                        scanf("%d%*c", &position);
                        int field = fields(); //Select field to search by
                        printViaPosField_RDR(output_file,position,field);
                        break;

                case 5:// Exit program
                        stop = true; //Stop while and exit
                        break;

                default:
                        printf("Option was not selected");
                        break;
                }
                
                
        case 3: //RFF
                output_file = createNewFile_RFF(file_name);
                while(!stop){
                        menu_op = menu();
                        switch (menu_op) {
                        case 1:         // Show data from file
                                printAll_RFF(output_file);
                                break;

                        case 2:// Search by given value
                                field = fields();        //Select field to search by
                                printf("Type the what to search.\n>>>" );
                                key = readString();
                                printViaField_RFF(output_file,field,key);
                                break;

                        case 3:         // Show data from a record
                                printf("Type the record number.\n>>>");
                                scanf("%d%*c",&position);
                                printViaPosition_RFF(output_file,position);
                                break;

                        case 4:        // Show data frome a given record and field
                                printf("Type the register number.\n>>>");
                                scanf("%d%*c", &position);
                                int field = fields();        //Select field to search by

                                printViaPosField_RFF(output_file,position,field);

                                break;

                        case 5:// Exit program
                                stop = true;        //Stop while and exit
                                break;

                        default:
                                printf("Option was not selected.\n");
                                break;
                        }
                       
                }        

        }

        // Dealocating the string 
        free(output_file);

        return EXIT_SUCCESS;
}
